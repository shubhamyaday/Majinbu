function cancel() {
  document.getElementById('password').value = "";
}
