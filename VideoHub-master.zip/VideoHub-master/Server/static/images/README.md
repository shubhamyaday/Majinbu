Places video previews here.
